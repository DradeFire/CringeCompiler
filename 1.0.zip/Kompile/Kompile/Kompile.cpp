﻿

#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

int main()
{
    string buff; // буфер промежуточного хранения считываемого из файла текста
    ifstream mFile("C://Users//stepa//Desktop//dd.txt"); 
    map<string, int> localInts; // имя + значение локальной переменной int
    map<string, char> localChars; // имя + значение локальной переменной char
    map<string, short> localShorts; // имя + значение локальной переменной short
    string key;
    int val;
    char cval;
    short sval;
    if (!mFile.is_open()) // если файл не открыт
        cout << "Файл не может быть открыт!\n"; // сообщить об этом
    else
    {
        
        while (mFile) {
            mFile >> buff; // считали слово из файла
            if (buff == "int") {
                mFile >> key;
                mFile >> buff;
                mFile >> buff;
                val = stoi(buff);
                localInts[key] = val;
                cout << key;
                cout << localInts[key];
            }
        }
        
        mFile.close(); // закрываем файл
    }
    ifstream mFile1("C://Users//stepa//Desktop//dd.txt");
    if (!mFile1.is_open()) // если файл не открыт
        cout << "Файл не может быть открыт!\n"; // сообщить об этом
    else
    {

        while (mFile1) {
            mFile1 >> buff; // считали слово из файла
            if (buff == "char") {
                mFile1 >> key;
                mFile1 >> buff;
                mFile1 >> cval;
                localChars[key] = cval;
                cout << key;
                cout << localChars[key];
            }
        }

        mFile1.close(); // закрываем файл
    }
    ifstream mFile2("C://Users//stepa//Desktop//dd.txt");
    if (!mFile2.is_open()) // если файл не открыт
        cout << "Файл не может быть открыт!\n"; // сообщить об этом
    else
    {

        while (mFile2) {
            mFile2 >> buff; // считали слово из файла
            if (buff == "short") {
                mFile2 >> key;
                mFile2 >> buff;
                mFile2 >> buff;
                sval = stoi(buff);
                localShorts[key] = sval;
                cout << key;
                cout << localShorts[key];
            }
        }

        mFile2.close(); // закрываем файл
    }
}
